{
    'name': "Gestión de Filàs",
    'version': "1.0",
    'summary': "Mòdul per a la gestió de socis, filaes, historial i montepios",
    'description': """
Aquest mòdul permet gestionar els socis d'una filà, les filaes, el seu historial d'altes i baixes,
i les aportacions (montepios) realitzades pels socis.

Inclou:
- Model Socios (hereta de res.partner) amb camps com Data de Naixement, Filàs assignades, etc.
- Model Filaes amb camps com CIF, Nom, Any de Fundació i càlcul del nombre de components.
- Model Historial que registra altes i baixes en cada filà.
- Model Montepios per a la gestió d'aportacions, amb validacions que impedeixen aportacions si el soci està de baixa.
- Vistes Tree, Form, Kanban i Graph per als models corresponents, així com informes integrats.
    """,
    'author': "Joan Ripoll Abad",
    'website': "https://github.com/JoanRipollAbad",
    'category': "Management",
    'depends': ['base'],
    'data': [
         'security/ir.model.access.csv',
         'views/socios_views.xml',
         'views/filaes_views.xml',
         'views/historial_views.xml',
         'views/montepios_views.xml',
         'reports/report_filaes_informe_templates.xml',
         'reports/report.xml',
         'views/menu.xml',
    ],
    'installable': True,
    'application': True,
}

