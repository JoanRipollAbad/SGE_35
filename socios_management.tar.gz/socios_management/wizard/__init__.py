# -*- coding: utf-8 -*-
from . import soci_alta_wizard
from . import soci_baixa_wizard

