from odoo import models, fields, api

class Montepios(models.Model):
    _name = 'gestion_filaes.montepios'
    
    socio_id = fields.Many2one('gestion_filaes.socios', string="Soci", required=True)
    filada_id = fields.Many2one('gestion_filaes.filaes', string="Filà", required=True)
    aportacio = fields.Float(string="Aportació", required=True)
    data_aportacio = fields.Date(string="Data Aportació", default=fields.Date.today)


