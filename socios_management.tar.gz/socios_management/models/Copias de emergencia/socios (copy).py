from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import date

class Socios(models.Model):
    _name = 'gestion_filaes.socios'
    _inherits = {'res.partner': 'partner_id'}
    
    partner_id = fields.Many2one('res.partner', required=True, ondelete='cascade')
    fecha_nacimiento = fields.Date(string="Fecha de Nacimiento", required=True)
    filada_ids = fields.Many2many('gestion_filaes.filaes', string="Filàs")
    certificat_minusvalidesa = fields.Image(string="Certificat de Minusvalidesa")
    condicio = fields.Selection(
        [('jovenil', 'Jovenil'), ('actiu', 'Actiu'), ('baixa', 'Baixa'),
         ('honorari', 'Honorari'), ('social', 'Social')],
        string="Condició", compute="_compute_condicio", store=True)
    antiguitat = fields.Integer(string="Antiguitat en la Filà", compute="_compute_antiguitat", store=True)
    fila_status_ids = fields.One2many(
        'gestion_filaes.filaestatus', 'soci_id', string="Estats en les Filaes"
    )

    @api.model
    def create(self, vals):
        record = super(Socios, self).create(vals)
        if 'filada_ids' in vals and isinstance(vals['filada_ids'], list):
            for operacio in vals['filada_ids']:
                if isinstance(operacio, tuple) and len(operacio) >= 3 and isinstance(operacio[2], list):
                    for filada_id in operacio[2]:
                        if filada_id:
                            self.env['gestion_filaes.filaestatus'].create({
                                'soci_id': record.id,
                                'filada_id': filada_id,  # S'ha canviat de 'filae_id' a 'filada_id'
                                'estat': 'alta',
                            })
        return record
    
    def write(self, vals):
        result = super(Socios, self).write(vals)
        if 'filada_ids' in vals and isinstance(vals['filada_ids'], list):
            for record in self:
                for operacio in vals['filada_ids']:
                    if isinstance(operacio, tuple) and len(operacio) >= 3 and isinstance(operacio[2], list):
                        noves_filades = set(operacio[2]) if operacio[2] else set()
                        filades_actuals = set(record.filada_ids.ids)

                        for filada_id in noves_filades - filades_actuals:
                            self.env['gestion_filaes.filaestatus'].create({
                                'soci_id': record.id,
                                'filada_id': filada_id,  # S'ha canviat de 'filae_id' a 'filada_id'
                                'estat': 'alta',
                            })
                        
                        for filada_id in filades_actuals - noves_filades:
                            estatus = self.env['gestion_filaes.filaestatus'].search([
                                ('soci_id', '=', record.id),
                                ('filada_id', '=', filada_id)  # Aquí també
                            ])
                            estatus.write({'estat': 'baixa'})
        return result
    
    @api.depends('fecha_nacimiento', 'certificat_minusvalidesa', 'fila_status_ids.estat')
    def _compute_condicio(self):
        today = date.today()
        for record in self:
            edat = (today - record.fecha_nacimiento).days // 365 if record.fecha_nacimiento else 0
            anys_filada = sum([(today - h.fecha_accion).days // 365 for h in record.fila_status_ids if h.estat == 'alta'])
            
            if record.certificat_minusvalidesa:
                record.condicio = 'social'
            elif anys_filada >= 30 and edat >= 70:
                record.condicio = 'honorari'
            elif edat < 18:
                record.condicio = 'jovenil'
            elif edat >= 18:
                record.condicio = 'actiu'
            else:
                record.condicio = 'baixa'
    
    @api.depends('fila_status_ids')
    def _compute_antiguitat(self):
        today = fields.Date.today()
        for record in self:
            antiguitat = 0
            for fila_status in record.fila_status_ids:
                if fila_status.estat == 'alta':
                    antiguitat += (today - fila_status.fecha_accion).days // 365
            record.antiguitat = antiguitat
            
    def alta_fila(self, fila_id):
        """Donar d'alta un soci en una filà específica."""
        fila_status = self.fila_status_ids.filtered(lambda f: f.filada_id.id == fila_id)
        if fila_status and fila_status.estat == 'alta':
            raise ValidationError("El soci ja està donat de alta en aquesta filà.")
        elif fila_status and fila_status.estat == 'baixa':
            fila_status.write({'estat': 'alta', 'fecha_accion': fields.Date.today()})
        else:
            self.env['gestion_filaes.filaestatus'].create({
                'soci_id': self.id,
                'filada_id': fila_id,
                'estat': 'alta',
                'fecha_accion': fields.Date.today()
            })

    def baixa_fila(self, fila_id):
        """Donar de baixa un soci d'una filà específica."""
        fila_status = self.fila_status_ids.filtered(lambda f: f.filada_id.id == fila_id)
        if not fila_status or fila_status.estat == 'baixa':
            raise ValidationError("El soci no pertany a aquesta filà o ja està donat de baixa.")
        fila_status.write({'estat': 'baixa', 'fecha_accion': fields.Date.today()})

