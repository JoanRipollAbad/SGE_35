from odoo import models, fields, api

class Filaes(models.Model):
    _name = 'gestion_filaes.filaes'
    
    name = fields.Char(string="Nom", required=True)
    cif = fields.Char(string="CIF")
    any_fundacio = fields.Date(string="Any Fundació")
    nombre_components = fields.Integer(string="Nombre de components", compute="_compute_nombre_components", store=True)
    socios_ids = fields.Many2many('gestion_filaes.socios', string="Socis")
    historial_ids = fields.One2many('gestion_filaes.historial', 'filada_id', string="Historial")  # 🔹 Afegit aquest camp
    


    @api.depends('socios_ids')
    def _compute_nombre_components(self):
        for record in self:
            record.nombre_components = len(record.socios_ids)


