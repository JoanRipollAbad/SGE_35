from odoo import models, fields, api, exceptions

class FilaeStatus(models.Model):
    _name = "gestion_filaes.filaestatus"
    _description = "Estat del soci dins d'una filà"
    
    # Eliminem el camp innecessari: filada_status_ids
    # filada_status_ids = fields.One2many(
    #     'gestion_filaes.filaestatus',  
    #     'socio_id',                    
    #     string="Estat en Filaes"
    # )
    
    soci_id = fields.Many2one(
        'gestion_filaes.socios', 
        string="Soci", 
        required=True, 
        ondelete='cascade'
    )
    filada_id = fields.Many2one(
        'gestion_filaes.filaes', 
        string="Filà", 
        required=True
    )
    estat = fields.Selection([
        ('alta', "Alta"),
        ('baixa', "Baixa")
    ], string="Estat", default="alta")
    fecha_accion = fields.Date(
        string="Data de l'Acció", 
        default=fields.Date.today, 
        required=True
    )

    _sql_constraints = [
        ('unique_filae_soci', 'unique(soci_id, filada_id)', 
         "Un soci no pot estar duplicat en la mateixa filà."),
    ]

    @api.constrains('estat')
    def check_estat_logic(self):
        for record in self:
            # La lògica pot variar segons la teva necessitat. Aquí es fa servir la relació
            # many2many 'filada_ids' definida en el model Socios per comprovar si el soci ja té
            # assignada la filà.
            if record.estat == 'alta' and record.filada_id.id in record.soci_id.filada_ids.ids:
                raise exceptions.ValidationError("El soci ja està actiu en aquesta filà.")
            if record.estat == 'baixa' and record.filada_id.id not in record.soci_id.filada_ids.ids:
                raise exceptions.ValidationError("El soci no pot ser donat de baixa perquè no està en la filà.")
                
    def action_donar_alta(self):
        for record in self:
            if record.estat != 'alta':
                record.write({'estat': 'alta', 'fecha_accion': fields.Date.today()})

    def action_donar_baixa(self):
        for record in self:
            if record.estat != 'baixa':
                record.write({'estat': 'baixa', 'fecha_accion': fields.Date.today()})


