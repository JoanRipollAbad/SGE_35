from odoo.exceptions import ValidationError
from odoo import models, fields, api

class Historial(models.Model):
    _name = 'gestion_filaes.historial'
    _description = 'Historial de Socios en Filàs'

    socio_id = fields.Many2one('gestion_filaes.socios', string="Soci", required=True)
    filada_id = fields.Many2one('gestion_filaes.filaes', string="Filà", required=True)
    accion = fields.Selection([('alta', 'Alta'), ('baixa', 'Baixa')], string="Acció", required=True)
    fecha_accion = fields.Date(string="Data de l'Acció", required=True, default=fields.Date.today)

    
    
    @api.constrains('socio_id', 'filada_id', 'accion')
    def _check_soci_filada(self):
        for record in self:
            historial = self.env['gestion_filaes.historial'].search([
                ('socio_id', '=', record.socio_id.id),
                ('filada_id', '=', record.filada_id.id)
            ])

            altes = historial.filtered(lambda h: h.accion == 'alta')
            baixes = historial.filtered(lambda h: h.accion == 'baixa')

            if record.accion == 'alta' and altes and (len(altes) > len(baixes)):
                raise ValidationError("Aquest soci ja està en la filà i no pot ser donat d'alta de nou.")

            if record.accion == 'baixa' and not altes:
                raise ValidationError("Aquest soci no pot ser donat de baixa perquè no pertany a la filà.")

