# -*- coding: utf-8 -*-
# Aqui indicamos que se cargara el fichero "biblioteca_comic.py"
# Si creamos mas modelos, deben importarse en este fichero
from . import biblioteca_comic
from . import comic
from . import socio
from . import ejemplar
